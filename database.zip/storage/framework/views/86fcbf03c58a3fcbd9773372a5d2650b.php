
<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="h-screen w-screen bg-black text-white bg-opacity-80 flex items-center align-baseline justify-center">
        <div class="w-11/12 h-full p-6 flex justify-center text-center items-center flex-col">
            <svg xmlns="http://www.w3.org/2000/svg" height="240px" class="" viewBox="0 -960 960 960" width="240px" fill="#ef4444"><path d="M480-280q17 0 28.5-11.5T520-320q0-17-11.5-28.5T480-360q-17 0-28.5 11.5T440-320q0 17 11.5 28.5T480-280Zm-40-160h80v-240h-80v240Zm40 360q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/></svg>
            
            <?php if(request()->get('info') == "age" || request()->get('info') == null): ?>
                <h2 class="text-2xl text-center w-full sm:text-3xl lg:text-4xl text-red-500">Мы не можем вас зарегистрировать!</h2>
                <p class="sm:text-base text-sm text-center mt-8 w-full">К сожалению мы не можем вас зарегистрировать, <strong class="text-red-500">из-за вашего возраста.</strong> Ведь подростковые лагерь проводится для подростков 14-16 лет.</p>                                 
            <?php elseif(request()->get('info') == "reserve"): ?>
                <h2 class="text-2xl text-center w-full sm:text-3xl lg:text-4xl"><strong class=" text-red-500">Внимание! Вы в резерве</strong></h2>
                <p class="sm:text-base text-sm text-center mt-8 w-full">К сожалению места для <?php echo e(request()->get('pol') == 'man' ? 'мальчиков' : 'девочек'); ?> закончились. <strong class="text-red-500">Мы зарегистрировали вас в резерв. Пока что вы не попадаете в смену.</strong> Что это означает? Это означает, что если кто-то из зарегистрированных ребят откажется от поездки, то мы заменим его на человека из резерва. Так что у вас все еще есть шанс попасть на смену! Если это произойдет, <strong class="text-red-500">мы вас обязательно оповестим. Если никакого оповещения не будет - то к сожалению вы не попадаете в смену, так как места законичлись.</strong> Пока что вы находитесь в резерве, и не попадаете в смену.</p>                                 
            <?php else: ?>
                <p class="sm:text-base text-sm text-center mt-8 w-full">К сожалению мы не можем вас зарегистрировать, из-за вашего возраста. Ведь подростковые лагерь проводится для подростков 14-16 лет.</p>                                 
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?><?php /**PATH D:\projects\laravel\FormApp\resources\views/form/rejection.blade.php ENDPATH**/ ?>