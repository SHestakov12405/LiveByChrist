<?php
    $groupId = 0;
?>
<table>
    <!-- Заголовок -->
    <tr>

    </tr>    
    <tr>
        <td colspan="4" style="font-size: 16px; font-weight: bold; text-align: center; background-color: #f2f2f2;">
            Участники мероприятия
        </td>
    </tr>

    <!-- Подзаголовки -->
    <tr>
        <th>"№<br>п/п"</th>
        <th>ФИО</th>
        <th>Наставник/участник</th>
        <th>Дата рождения</th>
        <th>Возраст</th>
        <th>Email</th>
        <th>Телефон</th>
        <th>Церковь</th>
        <th>Наставник</th>
        <th>Проживание</th>
        <th>Деньги при заезде</th>
        <th>Остаток</th>
        <th>Примечания</th>
    </tr>

    <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if($groupId !== $participant->group()->first()->id): ?>
        <?php $__currentLoopData = $participant->group()->first()->mentors()->orderBy('main', 'asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($mentor)): ?>
                <tr>
                    <td></td>
                    <td><?php echo e("$mentor->surname $mentor->name $mentor->patronymic"); ?></td>
                    <td>Наставник</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><?php echo e($mentor->group()->location()->first()->title); ?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!-- Данные -->
    
    <tr>
        <td><?php echo e($key); ?></td>
        <td><?php echo e("$participant->surname $participant->name $participant->patronymic"); ?></td>
        <td>Участник</td>
        <td><?php echo e($participant->date_bird); ?></td>
        <td><?php echo e($participant->age); ?></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td><?php echo e($participant->group()->first()->location()->first()->title); ?></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    
    <?php echo e($groupId == $participant->group_id); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH D:\projects\laravel\FormApp\resources\views/exports/participants.blade.php ENDPATH**/ ?>