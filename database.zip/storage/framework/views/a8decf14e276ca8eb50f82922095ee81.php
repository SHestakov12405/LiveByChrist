<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    

<div class="w-full mx-auto p-6 md:p-14 bg-black bg-opacity-60 text-gray-200">

    <p class="italic text-center text-3xl mt-9 md:mt-0 mb-4">
        &laquo;потому что Бог не есть Бог неустройства, но мира&raquo; (1 Кор. 14:33)
    </p>
    <div class="bg-gray-950 border-gray-800 border p-5 mt-10 bg-opacity-80 rounded-xl">
        <h2 class="text-xl font-bold mt-4 mb-4">Правила выезда:</h2>
        <p class="mb-4">
            Регистрация участника и заезд на территорию базы означает полное согласие участника/участницы с нижеперечисленными правилами:
        </p>
    

        <ul class="list-disc pl-5 space-y-2 mb-6">
            <li><strong>Соблюдение установленных правил</strong> является обязательным условием пребывания на территории базы и участия всех, без исключения, участников.</li>
            <li><strong>Расселение по комнатам</strong> производится согласно спискам, сформированным администрацией выезда.</li>
            <li><strong>Администрация выезда</strong> оставляет за собой право аннулировать путевку, с отказом в пребывании участника на территории базы, без возврата денежных средств, за несоблюдение установленных правил. При этом участник, путевка которого аннулирована, самостоятельно обеспечивает выезд с территории базы до места постоянного жительства.</li>
            <li><strong>В случае умышленного или неумышленного нанесения ущерба имуществу</strong>, помещениям, инвентарю, технике и т. д., принадлежащим собственнику базы или организаторам выезда, участник, совершивший данное деяние, несет полную материальную ответственность и обязан возместить нанесенный ущерб.</li>
            <li><strong>Организаторы выезда, а также собственник базы не несут ответственность за сохранность вещей</strong>, в том числе ценных. Сообщаем, что организаторы выезда не имеют в наличии сейфов, закрываемых помещений для обеспечения сохранности ценных вещей, а также жилые помещения на протяжении всего выезда на ключ не закрываются для обеспечения свободного доступа проживающих участников.</li>
        </ul>
    </div>

    <div class="bg-gray-950 border-gray-800 border p-5 mt-10 bg-opacity-80 rounded-xl">
        <h2 class="text-xl font-bold mb-4">Обязанности участников выезда:</h2>
        <p class="mb-4">
            Мы желаем, чтобы вы провели время на выезде с пользой для вашей духовной жизни, и именно поэтому исключаем всякое использование мобильного телефона на выезде, за исключением случаев срочной необходимости.
        </p>

        <ul class="list-disc pl-5 space-y-2 mb-6">
            <li><strong>Соблюдать нормы приличного внешнего вида</strong>, установленные христианскими принципами, целомудрием и взглядами поместных церквей Брянской области.
                <br><span class="italic">«Юношей также увещевай быть целомудренными.» (Тит. 2:6)</span>
                <br><span class="italic">«На женщине не должно быть мужской одежды, и мужчина не должен одеваться в женское платье, ибо мерзок пред Господом Богом твоим всякий делающий сие.» (Втор. 22:5)</span>
            </li>
            <li><strong>Соблюдать и поддерживать порядок и чистоту</strong> в жилых помещениях и на всей территории базы;</li>
            <li><strong>Посещать все мероприятия по распорядку дня</strong> (зарядка, утренние и вечерние встречи, приём пищи, игры, семинары и т.д.);</li>
            <li><strong>Взять одежду соответствующую для различных видов программы:</strong>
                <ul class=" mt-2">
                    <li>1. Утренние и вечерние встречи;</li>
                    <li>2. Купание: братья — шорты; сестры — шорты, футболка;</li>
                    <li>3. Спортивные игры;</li>
                    <li>4. Прочие мероприятия</li>
                </ul>
            </li>
        </ul>
    </div>

    <div class="bg-gray-950 border-gray-800 border p-5 mt-10 bg-opacity-80 rounded-xl">
        <h2 class="text-xl font-bold mb-4">Участникам выезда запрещается:</h2>

        <ul class="list-disc pl-5 space-y-2 mb-6">
            <li><strong>Употреблять или хранить спиртные напитки, табачные изделия или наркотические вещества</strong>, а также использовать различные виды электронных сигарет (вейпы и прочие).</li>
            <li><strong>Любые виды азартных игр.</strong></li>
            <li><strong>Самовольно покидать территорию выезда.</strong></li>
            <li><strong>Одиночные купания; катания на лодках.</strong></li>
            <li><strong>Находиться в помещениях для отдыха противоположного пола.</strong></li>
            <li><strong>Употреблять в разговоре грубые, скверные слова.</strong>
                <br><span class="italic">«Никакое гнилое слово да не исходит из уст ваших, а только доброе для назидания в вере, дабы оно доставляло благодать слушающим.» (Еф. 4:29)</span>
            </li>
        </ul>
    </div>

</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH D:\projects\laravel\FormApp\resources\views/form/reglaments.blade.php ENDPATH**/ ?>