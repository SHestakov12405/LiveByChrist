<?php
// Список цветов в HEX без #
$colors = ['d9e1f2', 'e2efda', 'fff2cc', 'fce4d6'];
$colorIndex = $pol == 'man' ? 0 : 2;
$undefinedParticipants = [];
?>
<table>
    <!-- Заголовок -->
    <tr>

    </tr>    
    <tr>
        <td colspan="14" style="font-size: 20px; text-align: center;">
            <?php echo e($pol == 'man' ? 'Братья' : 'Сестры'); ?>, подростковая смена 7 - 12 июля 2025
        </td>
    </tr>
    <tr>
        <td colspan="14" style="font-size: 16px; font-weight: bold; text-align: center;">

        </td>
    </tr>

    <!-- Подзаголовки -->
    <tr style="border: 4px solid #000;">
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">"№<br>п/п"</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">ФИО</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Наставник/участник</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Дата рождения</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Возраст</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Email</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Телефон</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Церковь</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Наставник</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Проживание</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Деньги при заезде</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Остаток</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Болезни участника</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Примечания</th>
    </tr>

    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php if((int)$group->age !== -1): ?>
                
            
            <?php
                // Получаем текущий цвет
                $bgColor = $colors[$colorIndex % count($colors)];
                $colorIndex++;
            ?>
            <?php $__currentLoopData = $group->mentors()->orderByDesc('main')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="background-color: #<?php echo e($bgColor); ?>; font-weight: extrabold; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; font-weight: bold; border: 1px solid #000; text-align: center"><?php echo e("$mentor->surname $mentor->name $mentor->patronymic"); ?></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; font-weight: bold; border: 1px solid #000; text-align: center">Наставник</td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e($group->location()->first()->title); ?> (<?php echo e($group->location()->first()->seats); ?> мест)</td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- Данные -->
            <?php $__currentLoopData = $group->participants()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e($key + 1); ?></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e("$participant->surname $participant->name $participant->patronymic"); ?></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center">Участник</td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e($participant->date_bird); ?></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e($participant->age); ?></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e($participant->email); ?></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e($participant->phone); ?></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e($participant->church); ?></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e($group->mentors()->orderByDesc('main')->first() ? $group->mentors()->orderByDesc('main')->first()->surname . " " . $group->mentors()->orderByDesc('main')->first()->name : "Неопределён"); ?></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e($group->location()->first()->title); ?> (<?php echo e($group->location()->first()->seats); ?> мест)</td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"><?php echo e($participant->diseases ? $participant->diseases : 'Нет'); ?></td>
                    <td style="background-color: #<?php echo e($bgColor); ?>; border: 1px solid #000; text-align: center"></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
    </tr>
     <tr>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
    </tr>
     <tr>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
    </tr>
    <tr>
        <td colspan="14" style="font-size: 20px;">
            Резерв
        </td>
    </tr>
    <tr style="border: 4px solid #000;">
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">"№<br>п/п"</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">ФИО</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Наставник/участник</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Дата рождения</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Возраст</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Email</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Телефон</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Церковь</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Наставник</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Проживание</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Деньги при заезде</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Остаток</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Болезни участника</th>
        <th style="text-align: center; vertical-align: middle; font-weight: bold; border: 1px solid #000;">Примечания</th>
    </tr>
    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if((int)$group->age == -1): ?>
            <!-- Данные -->
            <?php $__currentLoopData = $group->participants()->orderBy('age')->orderBy('created_at')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border: 1px solid #000; text-align: center"><?php echo e($key + 1); ?></td>
                    <td style="border: 1px solid #000; text-align: center"><?php echo e("$participant->surname $participant->name $participant->patronymic"); ?></td>
                    <td style="border: 1px solid #000; text-align: center">Участник</td>
                    <td style="border: 1px solid #000; text-align: center"><?php echo e($participant->date_bird); ?></td>
                    <td style="border: 1px solid #000; text-align: center"><?php echo e($participant->age); ?></td>
                    <td style="border: 1px solid #000; text-align: center"><?php echo e($participant->email); ?></td>
                    <td style="border: 1px solid #000; text-align: center"><?php echo e($participant->phone); ?></td>
                    <td style="border: 1px solid #000; text-align: center"><?php echo e($participant->church); ?></td>
                    <td style="border: 1px solid #000; text-align: center">-</td>
                    <td style="border: 1px solid #000; text-align: center">-</td>
                    <td style="border: 1px solid #000; text-align: center"></td>
                    <td style="border: 1px solid #000; text-align: center"></td>
                    <td style="border: 1px solid #000; text-align: center"><?php echo e($participant->diseases ? $participant->diseases : 'Нет'); ?></td>
                    <td style="border: 1px solid #000; text-align: center"></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</table><?php /**PATH D:\projects\laravel\FormApp\resources\views/exports/groups.blade.php ENDPATH**/ ?>