<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans min-h-dvh text-gray-900 bg-[rgb(20,20,20)] antialiased bg-[url(/public/assets/images/fon.jpg)] bg-cover bg-center md:bg-[url(/public/assets/images/fonmax.jpg)] bg-no-repeat bg-fixed"  style="">
        <div>
            <?php echo e($slot); ?>

        </div>
        <script src="https://cdn.jsdelivr.net/npm/flowbite@3.1.2/dist/flowbite.min.js"></script>
    </body>
</html>
<?php /**PATH D:\projects\laravel\FormApp\resources\views/layouts/main.blade.php ENDPATH**/ ?>