Здравствуйте, <?php echo e($participant->name); ?>!
Вы успешно зарегистрировались на подростковую смену в Бытошь.
Ваше приблизительные данные:
<?php if($participant->group->mentors->count()): ?>
Наставники: <?php echo e($participant->group->mentors->map(fn($mentor) => "$mentor->surname $mentor->name")->join(', ')); ?>

<?php else: ?>
Наставники: для вас пока что не назначены
<?php endif; ?>

<?php if($participant->group->location->count()): ?>
Жилье: <?php echo e($participant->group->location->title); ?>

<?php else: ?>
Жилье: для вас пока что не назначены
<?php endif; ?><?php /**PATH D:\projects\laravel\FormApp\resources\views/sms/participant.blade.php ENDPATH**/ ?>