<?php

use App\Exports\AllExport;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FormController;
use App\Http\Middleware\OnlyFromRedirect;
use App\Http\Controllers\ProfileController;
use App\Http\Middleware\CheckPageAccessKey;

Route::get('/', [FormController::class, 'index'])->name('index');
// ->middleware(CheckPageAccessKey::class);
Route::post('/form', [FormController::class, 'form'])->name('form');
Route::get('/reglaments', [FormController::class, 'reglaments'])->name('reglaments');
// ->middleware(CheckPageAccessKey::class);
Route::get('/rejection', [FormController::class, 'rejection'])->name('rejection');
// ->middleware(OnlyFromRedirect::class);
Route::get('/success', [FormController::class, 'success'])->name('success');
// ->middleware(OnlyFromRedirect::class);
// Route::get('/email', function(){
//     Mail::to('anton.shestakov.2005@mail.ru')->send(new ParticipantEmail($participant));
// })->name('success');


Route::get('/export', function () {
    return Excel::download(new AllExport, 'Регистрация Бытошь.xlsx');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
